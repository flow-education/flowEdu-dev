CREATE PROCEDURE `sp_select_next_private_letter_sequence`()
  BEGIN
    UPDATE PRIVATE_LETTER_SEQ SET sequence = @sequence := sequence +1 LIMIT 1;
    SELECT @sequence as sequence;
  END