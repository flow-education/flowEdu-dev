CREATE PROCEDURE `sp_select_next_user_push_sequence`(IN `in_user_id` MEDIUMTEXT)
  BEGIN
    UPDATE USER_PUSH_SEQ SET push_seq = @push_seq := push_seq +1 WHERE user_id = in_user_id LIMIT 1;
    SELECT @push_seq as push_seq;
  END